<?php


session_start();
unset($_SESSION['email']);  

include_once('DBConn.php');
//include_once('createTable.php');


$output = NULL;
$email = $pass = "";

if(isset($_POST['submit']))
{

    $_SESSION['email'] = $_POST['email'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $hpass = md5($pass);

    $query = "SELECT email, password FROM tbladmin WHERE email = '$email' AND password = '$pass'";
    
    $result = mysqli_query($conn,$query);

    $row = mysqli_fetch_array($result);



    if(empty($email))
    {
        $output = "Please enter email";
    }

    else 
    { 
         if($row['email'] == $email && $row['password'] == $pass) 
         {
             header("location: admin.php");
         }
        else 
        {
            $output = "Incorrect Username\Password";
        }
    
    }
    
    
    
  

}
?>

<!DOCTYPE html>
<html>
    <head>
		<title>WEGOTBOOKS</title>
    </head>
    
<body>
	
	<h1 style="text-align:center">WEGOTBOOKS</h1>
    <center>
	<h2>Admin Login</h2>
        <br>
        <br>
        <br>
    
    <form method="post">
        <table>
            <tr>
                <td>Admin Email :</td>
                <td> <input type="email" name = "email"  value = "<?php echo $email; ?>" ></td>
            </tr>
            <tr>
                <td>Admin Password :</td>
                <td> <input type="password" name = "pass"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="submit" value="Login"></td>
            </tr>
        </table>
    </form>
    <?php
    echo "<br>";
    echo $output;
    
    ?>
    <p>No Account? : Click here to <a href="login.php">Login</a></p> 
        </center>
        <img src="images/bikeHome.jpg" class="img-fluid" alt="...">
       
  <script src="js/bootstrap.js"></script>  

</body>


</html>