<?php

session_start();
if(!isset($_SESSION['email'])){
    header("location:login.php");
}

if(isset($_POST['submit']))
{
    header("location:login.php");
    
    unset($_SESSION['email']);  
    session_destroy(); 
}

if(isset($_POST['shop']))
{
    header("location:shop.php");
}

?>
<!DOCTYPE html>
<html>

<head>
		<title>WEGOTBOOKS</title>
    </head>
    
<body>
	
	<h1 style="text-align:center">WEGOTBOOKS</h1>
<center>

<p>Welcome <b><?php echo $_SESSION['email']; ?></b> You have successfully logged in!!!</p>

        <form method="post">
            <input type="submit" name="shop" value="Start Shopping" />

            <input type="submit" name="submit" value="Logout" />
        </form>

</center>

<script src="js/bootstrap.js"></script>  
</body>
</html>