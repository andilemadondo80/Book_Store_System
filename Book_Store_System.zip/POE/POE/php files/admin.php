<!DOCTYPE html>
<html>
      
<head>
    <title>
		Admin
    </title>
</head>
  
<body style="text-align:center;">
      
    <h1 style="color:green;">
        Welcome Admin
    </h1>
      
    <h4>
        Would you like to:
    </h4>
      
   
  
    <form method="post">
        <input type="submit" name="reg"
                class="button" value="Verification" />
          
        <input type="submit" name="add"
                class="button" value="ADD, UPDATE OR DELETE" />
		
		
    </form>
	 <?php
        if(array_key_exists('reg', $_POST)) {
            registration();
        }
        else if(array_key_exists('add', $_POST)) {
            addData();
        }
		
        function registration() {
            echo "this is the registration";
        }
        function addData() {
            echo "add";
			header("location:deleteBook.php");
			
        }
		
    ?>
</head>
  
</html>