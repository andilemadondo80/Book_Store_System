<?php


session_start();
unset($_SESSION['email']);  

include_once('DBConn.php');
//include_once('createTable.php');


$output = NULL;
$email = $pass = "";

if(isset($_POST['submit']))
{

    $_SESSION['email'] = $_POST['email'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $pass = md5($pass);

    $query = "SELECT email, password FROM tbluser WHERE email = '$email' AND password = '$pass'";
    
    $result = mysqli_query($conn,$query);

    $row = mysqli_fetch_array($result);



    if(empty($email))
    {
        $output = "Please enter email";
    }

    else 
    { 
         if($row['email'] == $email && $row['password'] == $pass) 
         {
             header("location: home.php");
         }
        else 
        {
            $output = "Incorrect Username\Password";
        }
    
    }
    
    
    
  

}
?>

<!DOCTYPE html>
<html>
    <head>
		<title>WEGOTBOOKS</title>
    </head>
    
<body>
	
	<h1 style="text-align:center">WEGOTBOOKS</h1>
    <center>
	<h2>Login</h2>
        <br>
        <br>
        <br>
    
    <form method="post">
        <table>
            <tr>
                <td>Email :</td>
                <td> <input type="email" name = "email"  value = "<?php echo $email; ?>" ></td>
            </tr>
            <tr>
                <td>Password :</td>
                <td> <input type="password" name = "pass"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="submit" value="Login"></td>
            </tr>
        </table>
    </form>
    <?php
    echo "<br>";
    echo $output;
    
    ?>
    <p>No Account? : Click here to <a href="registration.php">Register</a></p> 
	 <p>Log in as admin: <a href="adminLogin.php">Admin Login</a></P>
        </center>
    

</body>


</html>