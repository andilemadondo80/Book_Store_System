<?php

//connecting to database
$conn = mysqli_connect('localhost','root','');

$dbName="bookstore";
 

//check connection
	if (!$conn) {
		
			die("Connection failed: " . mysqli_connect_error());
		 	
		}
		
		//echo "<br>Connected successfully<br>";


	$selectDB = mysqli_select_db($conn,$dbName);
	

		if (!$selectDB) {

		//creates database if database is not found
		$sql = "CREATE DATABASE ".$dbName."";
		
		mysqli_query($conn, $sql); 
		
		
		

		} 
	
	# new connection with database name specified
	
    $conn = mysqli_connect('localhost','root','',$dbName);

?>
