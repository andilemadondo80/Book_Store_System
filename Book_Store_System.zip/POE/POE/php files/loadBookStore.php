<?php 

	include_once('DBConn.php');
	
	//storing the query statements to create tables in strings
	$sqlc = "CREATE TABLE IF NOT EXISTS `tbladmin` (
  `adminID` int(50) NOT NULL AUTO_INCREMENT,
  `adminName` varchar(50) NOT NULL,
  `adminSurname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`adminID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1";

	$sqlb = "CREATE TABLE IF NOT EXISTS `tblbook` (
  `bookID` int(50) NOT NULL AUTO_INCREMENT,
  `bookName` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `bookCondition` varchar(50) NOT NULL,
  `price` decimal(50,0) NOT NULL,
  `adminID` int(50) NOT NULL,
  PRIMARY KEY (`bookID`),
  KEY `adminID` (`adminID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1";

	$sqla = "CREATE TABLE IF NOT EXISTS `tblorder` (
  `orderID` int(50) NOT NULL AUTO_INCREMENT,
  `userID` int(50) NOT NULL,
  `bookID` int(50) NOT NULL,
  `orderDate` date NOT NULL,
  PRIMARY KEY (`orderID`),
  KEY `userID` (`userID`),
  KEY `bookID` (`bookID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1";

	$sqld = "CREATE TABLE IF NOT EXISTS `tbluser` (
  `userID` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1";
	
	//deleting tables in database
	$dropTblA = mysqli_query($conn, "DROP TABLE IF EXISTS `tblorder`");
	$dropTblA = mysqli_query($conn, "DROP TABLE IF EXISTS `tblbook`");
	$dropTblA = mysqli_query($conn, "DROP TABLE IF EXISTS `tbluser`");
	$dropTblA = mysqli_query($conn, "DROP TABLE IF EXISTS `tbladmin`");

	//creating new tables in bookstore database
	$CreateTableA = mysqli_query($conn, $sqla);
	$CreateTableB = mysqli_query($conn, $sqlb);
	$CreateTableC = mysqli_query($conn, $sqlc);
	$CreateTableD = mysqli_query($conn, $sqld);
	
		//if statement to check if tables were created 
		if ($CreateTableA && $CreateTableB && $CreateTableC && $CreateTableD == TRUE) {
				
				echo "<br>Tables created<br>";
				#echo "There was an error :".mysqli_error($conn);
				
		}
			
		
		



?>