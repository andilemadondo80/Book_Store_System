<?php
	session_start();
	$mysqli = new mysqli('localhost', 'root', '', 'bookstore') or die(mysqli_error($mysqli)); 
	
	$update = false;
	$name = '';
	$author = '';
	$condition = '';
	$price ='';
	
	if(isset($_POST['save'])){
		$name = $_POST['name'];
		$author = $_POST['author'];
		$condition = $_POST['condition'];
		$price = $_POST['price'];
		
		$mysqli->query("INSERT INTO tblbook (bookName, author, bookCondition, price, adminID) VALUES('$name', '$author','$condition','$price','1')") or
				die($mysqli->error);
		
		$_SESSION['messege'] = "Record has been saved";
		$_SESSION['msg_type'] = "success";
		header("location: deleteBook.php");
	}
	
	if(isset($_GET['delete'])){
		$id = $_GET['delete'];
		$mysqli->query("DELETE FROM tblbook WHERE id=$id") or die($mysqli->error());
		$_SESSION['messege'] = "Record has been deleted";
		$_SESSION['msg_type'] = "Danger";
		header("location: deleteBook.php");
	}
	if(isset($_GET['edit'])){
		$id = $_GET['edit'];
		$update = true;
		$result = $mysqli->query("SELECT * FROM tblbook WHERE id=$id") or die($mysqli->error());
		if(count($result)==1){
			$row = $result->fetch_array();
			$name = $row['name'];
			$author = $row['author'];
			$condition = $row['condition'];
			$price = $row['price'];
		}
	}
	
	
?>
<!DOCTYPE html>
<html>
	<head>
		<title>PHPdelete</title>
		<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
		
	</head>
	<body>
	<?php 
		if(isset($_SESSION['messege'])): ?>
	
	<div class="alert alert-<?=$_SESSION['msg_type']?>">
		<?php 
			echo $_SESSION['messege'];
			unset($_SESSION['messege']);
		?>
	</div>
	<?php endif ?>
	<?php
	
		//$mysqli = new mysqli('localhost', 'root', '', 'crud') or die(mysqli_error($mysqli));
		$result = $mysqli->query("SELECT * FROM tblbook") or die($mysqli->error);
		//pre_r($result);
		//pre_r($result->fetch_assoc());
	?>
		
		<div>
		<table>
			<thead>
				<tr>
					<th>Book Name</th>
					<th>Author</th>
					<th>Book Condition</th>
					<th>Price</th>
					<th colspan="2">Action</th>
				</tr>
			</thead>
		<?php while($row = $result->fetch_assoc()): ?>
			<tr>
				<td> <?php echo $row['name']; ?></td>
				<td> <?php echo $row['author']; ?></td>
				<td> <?php echo $row['condition']; ?></td>
				<td> <?php echo $row['price']; ?></td>
				<td>
					<a href="deleteBook.php?edit=<?php echo $row['id']; ?>" 
					class="btb btn-info">Edit</a>
					<a href="deleteBook.php?delete=<?php echo $row['id']; ?>" 
					class="btb btn-info">Delete</a>
				</td>
			</tr>
			<?php endwhile; ?>
		</table>
		</div>	
			
	<?php
		function pre_r( $array){
			echo '<pre>';
			print_r($array);
			echo '</pre>';
		}
	
	?>
	
		<div class="row justify-content-center">
		<form method="POST">
			<div class="form-group">
			<label>Name</label>
			<input type="text" name="name" class="form-control" value="<?php echo $name; ?>" placeholder="Enter book name">
			</div>
			<div class="form-group">
			<lable>Author</label>
			<input type="text" name="author" class="form-control" value="<?php echo $author; ?>" placeholder="Enter author name">
			</div>
			<div class="form-group">
			<label>Condition</label>
			<input type="text" name="condition" class="form-control" value="<?php echo $condition; ?>" placeholder="Enter condition book">
			</div>
			<div class="form-group">
			<label>Price</label>
			<input type="text" name="price" class="form-control" value="<?php echo $price; ?>" placeholder="Enter book price">
			</div>
			<div class="form-group">
			<?php 
				if($update == true):
			?>
			<button type="submit" name="update">Update</button>
			<?php 
				else:
			?>
			<button type="submit" name="save">Save</button>
			<?php endif; ?>
			</div>
		</form>
		</div>
	</body>
</html>
