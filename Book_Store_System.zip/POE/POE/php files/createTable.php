<?php


		$sqla = "CREATE TABLE `tbluser` (
		  `userID` int(50) NOT NULL AUTO_INCREMENT,
		  `name` varchar(50) NOT NULL,
		  `surname` varchar(50) NOT NULL,
		  `email` varchar(50) NOT NULL,
		  `password` varchar(50) NOT NULL,
		  PRIMARY KEY (`userID`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1";

		
		
         include('DBConn.php');
		$CreateTableA = mysqli_query($conn, $sqla);
		
		

		if ($CreateTableA == TRUE) {
			
				echo "table was created";
				
		} else {

			echo "<br>Table exsist";
			
			//delete the table
			$sql = "DROP TABLE tbluser";
			
			if(mysqli_query($conn, $sql))
			{
				echo("This table has been deleted.");
				$CreateTableA = mysqli_query($conn, $sqla);
			}else{
			echo("Error deleting table " .mysqli_error($conn));
			}
			
			
			
			
		}

		$query = "SELECT * FROM tbluser";

		$result = mysqli_query($conn,$query);

		if (mysqli_num_rows($result) == 0) {
			
			loadData();
			echo "table was populated";
		}
		
	
	
		function loadData(){

		global $conn;

		$open = fopen('userData.txt','r');

		while (!feof($open)) 
			
			{
				$getTextLine = fgets($open);
				$explodeLine = explode(",",$getTextLine);

				list($fname,$lname,$email,$pass) = $explodeLine;

				$qry = "insert into tbluser
				(name, surname, email, password) values('$fname','$lname','$email','$pass')";
				mysqli_query($conn,$qry);
			}

		fclose($open);
		
		}

?>