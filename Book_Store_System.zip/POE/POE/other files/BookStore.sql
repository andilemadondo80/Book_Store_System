
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

DROP TABLE IF EXISTS `tbladmin`;
CREATE TABLE IF NOT EXISTS `tbladmin` (
  `adminID` intj(50) NOT NULL AUTO_INCREMENT,
  `adminName` varchar(50) NOT NULL,
  `adminSurname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`adminID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`adminID`, `adminName`, `adminSurname`, `email`, `password`) VALUES
(1, 'Tyreece', 'Nair', 'Tyreece@gmail.com', 'Tyreece'),
(2, 'Shereece', 'Nair', 'Shereece@gmail.com', 'Shereece'),
(3, 'Bazil', 'lizab', 'Bazil@gmail.com', 'adgaha123'),
(4, 'Kim', 'Mann', 'man@g.com', 'myssgas'),
(5, 'Taryn', 'Ash', 'ahe@.c', 'wqde');

-- --------------------------------------------------------

--
-- Table structure for table `tblbook`
--

DROP TABLE IF EXISTS `tblbook`;
CREATE TABLE IF NOT EXISTS `tblbook` (
  `bookID` int(50) NOT NULL AUTO_INCREMENT,
  `bookName` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `bookCondition` varchar(50) NOT NULL,
  `price` decimal(50,0) NOT NULL,
  `adminID` int(50) NOT NULL,
  PRIMARY KEY (`bookID`),
  KEY `adminID` (`adminID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbook`
--

INSERT INTO `tblbook` (`bookID`, `bookName`, `author`, `bookCondition`, `price`, `adminID`) VALUES
(8, 'Lion King', 'Lee', ' okay', '219', 1),
(9, 'Life of Pi', 'Leolen', ' fine', '210', 5),
(10, 'Van ', 'steave', 'good', '219', 2),
(11, 'Batman', 'Bruce', 'Ghotham city', '300', 3),
(12, 'king of the jungle', 'robert', 'fine', '200', 5),
(13, 'Steve  Biko', 'Steve Harvey', 'great', '450', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblorder`
--

DROP TABLE IF EXISTS `tblorder`;
CREATE TABLE IF NOT EXISTS `tblorder` (
  `orderID` int(50) NOT NULL AUTO_INCREMENT,
  `userID` int(50) NOT NULL,
  `bookID` int(50) NOT NULL,
  `orderDate` date NOT NULL,
  PRIMARY KEY (`orderID`),
  KEY `userID` (`userID`),
  KEY `bookID` (`bookID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblorder`
--

INSERT INTO `tblorder` (`orderID`, `userID`, `bookID`, `orderDate`) VALUES
(1, 11, 12, '2023-05-11'),
(2, 2, 9, '2023-04-19'),
(4, 9, 9, '2023-05-18'),
(5, 5, 10, '2023-05-10'),
(6, 4, 8, '2023-05-17'),
(7, 3, 9, '2023-05-25');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE IF NOT EXISTS `tbluser` (
  `userID` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`userID`, `name`, `surname`, `email`, `password`) VALUES
(1, 'Leolen', 'Nair', 'king@gmail.com', 'heAteCake'),
(2, 'Sam', 'james', 'sam@gmail.com', 'Handymanny'),
(3, 'sam', 'james', 'james@gmail.com', 'handymanny'),
(4, 'mike', 'tyson', 'mike@gmail.com', 'jeppy'),
(5, 'bruno', 'mars', 'mars@gmail.co.za', 'mars123'),
(6, 'steve', 'harvey', 'steavy.com', '234man'),
(7, 'lizel', 'andrews', 'lizel@gmail.com', 'super'),
(8, 'shelly', 'mustang', 'shelly@gmail.com', 'lovemovey'),
(9, 'kameshan', 'govener', 'ba@gmail.com', 'brother'),
(10, 'Bazil', 'Bazil', 'Bazil@gmail.com', 'Bazzy1'),
(11, 'Lerato', 'MOkoena', 'mam@gmail.com', 'Handymanny1');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblbook`
--
ALTER TABLE `tblbook`
  ADD CONSTRAINT `tblbook_ibfk_1` FOREIGN KEY (`adminID`) REFERENCES `tbladmin` (`adminID`);

--
-- Constraints for table `tblorder`
--
ALTER TABLE `tblorder`
  ADD CONSTRAINT `tblorder_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `tbluser` (`userID`),
  ADD CONSTRAINT `tblorder_ibfk_2` FOREIGN KEY (`bookID`) REFERENCES `tblbook` (`bookID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
