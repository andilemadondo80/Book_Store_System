<?php

session_start();
$connect = mysqli_connect("localhost", "root", "", "bookstore");

if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$count = count($_SESSION["shopping_cart"]);
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["hidden_name"],
				'item_price'		=>	$_POST["hidden_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			$_SESSION["shopping_cart"][$count] = $item_array;
		}
		else
		{
			echo '<script>alert("Item Already Added")</script>';
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_name'			=>	$_POST["hidden_name"],
			'item_price'		=>	$_POST["hidden_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Item Removed")</script>';
				echo '<script>window.location="books.php"</script>';
			}
		}
	}
}
?>

<html>

<head>
	     
		<title>Books</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
	
	<body>
	
	<div class= "header">
<div style="display: inline-block;">
  <div style="display: inline-block;" ><img class="headertitle-image" src="..\BookCart\images\logo.png" style="width:90px;height:90px;"></div>
    
  <div style="display: inline-block;">
<h1 class= "title-header">BOOKSTORE</h1>
</div>
</div>


<div class="search">    
    
<input class= "search" type="textbox" placeholder="Search..">
<button  class="search-submit"type="submit"> Submit</button>

</div>

<div class="accessories" >

<p class= "login-sign">Hi Reader!</p>
<p class= "login-sign">Login/Sign up</p>


<div>

<a href="#">
  <img  type="image" src="..\BookCart\images\wishlist.png" style="border: none;" height="50" width="50">
</a>

<a href="..\Final POE\CartO.php">
  <img src="..\BookCart\images\cart.png" style="border: none;" height="50" width="50">
</a>

</div>
</div>

</div>







<ul>

  <li class= "header-nav-link"><a href="#activ">Home</a></li>
  <li class= "header-nav-link"><a href="#news">Books</a></li>
  <li class= "header-nav-link"><a href="#contact">how it works</a></li>
  <li class= "header-nav-link"><a href="#about">Contact us</a></li>

</ul>

<br/>

		<div class="container">
			<br />
			<br />
			<br />
			<h3 align="center">Books</h3><br />
			<br /><br />

<section>
<?php
				$query = "SELECT * FROM tbl_product ORDER BY id ASC";
				$result = mysqli_query($connect, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
				?>
			<div class="col-md-4">
				<form method="post" action="books.php?action=add&id=<?php echo $row["id"]; ?>">
					<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
						<img src="images/<?php echo $row["image"]; ?>" class="img-responsive" /><br />

						<h4 class="text-info"><?php echo $row["name"]; ?></h4>

						<h4 class="text-danger">$ <?php echo $row["price"]; ?></h4>

						<input type="text" name="quantity" value="1" class="form-control" />

						<input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

						<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />

						<input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />

					</div>
				</form>
			</div>
		<section/>
			<?php
					}
				}
			?>
			
			 
	</body>

</html>